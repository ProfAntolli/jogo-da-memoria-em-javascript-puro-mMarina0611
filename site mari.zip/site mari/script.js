const cards = [
  "green", "green",
  "red", "red",
  "blue", "blue",
  "white", "white",
  "mango", "mango",
  "pipeline", "pipeline",
  "ultra", "ultra",
  "chaos", "chaos"
];

let firstCard = null;
let secondCard = null;
let lockBoard = false;
let moves = 0;
let matches = 0;
let timerStarted = false;
let time = 0;
let timerInterval;

const moveDisplay = document.getElementById("moves");
const matchDisplay = document.getElementById("matches");
const timerDisplay = document.getElementById("timer");

const clickSound = document.getElementById("clickSound");
const matchSound = document.getElementById("matchSound");
const mismatchSound = document.getElementById("mismatchSound");

function updateStats() {
  moveDisplay.textContent = `Jogadas: ${moves}`;
  matchDisplay.textContent = `Pares encontrados: ${matches}`;
}

function startTimer() {
  timerInterval = setInterval(() => {
    time++;
    timerDisplay.textContent = `Tempo: ${time}s`;
  }, 1000);
}

function createCard(flavor) {
  const card = document.createElement("div");
  card.classList.add("card");
  card.dataset.flavor = flavor;

  const inner = document.createElement("div");
  inner.classList.add("card-inner");

  const front = document.createElement("div");
  front.classList.add("card-front");
  const img = document.createElement("img");
  img.src = `images/${flavor}.png`;
  img.alt = flavor;
  front.appendChild(img);

  const back = document.createElement("div");
  back.classList.add("card-back");

  inner.appendChild(front);
  inner.appendChild(back);
  card.appendChild(inner);

  card.addEventListener("click", flipCard);

  return card;
}

function flipCard() {
  if (!timerStarted) {
    startTimer();
    timerStarted = true;
  
    const bgMusic = document.getElementById("bg-music");
  if (bgMusic && bgMusic.paused) {
    bgMusic.play().catch(err => {
      console.warn("Autoplay bloqueado:", err);
  });
}
  }

  if (lockBoard || this.classList.contains("flipped")) return;

  clickSound.play();
  this.classList.add("flipped");

  if (!firstCard) {
    firstCard = this;
    return;
  }

  secondCard = this;
  moves++;
  updateStats();
  checkMatch();
}

function checkMatch() {
  const isMatch = firstCard.dataset.flavor === secondCard.dataset.flavor;

  if (isMatch) {
    matchSound.play();
    matches++;
    updateStats();
    disableCards();
  } else {
    mismatchSound.play();
    unflipCards();
  }
}

function disableCards() {
  firstCard.removeEventListener("click", flipCard);
  secondCard.removeEventListener("click", flipCard);
  resetBoard();
}

function unflipCards() {
  lockBoard = true;

  setTimeout(() => {
    firstCard.classList.remove("flipped");
    secondCard.classList.remove("flipped");
    resetBoard();
  }, 1000);
}

function resetBoard() {
  [firstCard, secondCard, lockBoard] = [null, null, false];
}

function shuffle(array) {
  return array.sort(() => Math.random() - 0.5);
}

function startGame() {
  const gameBoard = document.getElementById("gameBoard");
  const shuffled = shuffle(cards);

  shuffled.forEach(flavor => {
    const card = createCard(flavor);
    gameBoard.appendChild(card);
  });
}

startGame();
